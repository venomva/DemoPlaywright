import { expect, type Locator, type Page } from '@playwright/test';
import { BasePage } from './BasePage';

export const SHOP_TITLE = 'Shop · TestverQA';
export const SHOP_HEADING = 'Shop';
/** Prominent product shown on page 1 of the shop (position 1, featured). */
export const SHOP_FIRST_PRODUCT = 'Incredible Wooden Ball';
/** Cart CTA appears as "🛒 Cart (N)" where N is the line-item count. */
export const CART_COUNT_PREFIX = '🛒 Cart (';

/**
 * Shop (E-commerce flow) of the TestverQA playground.
 *
 * Guest exploration (staging, no restrictions): adding to cart, applying
 * coupons, and completing a 5-step checkout are legitimate sandbox journeys
 * (in-memory state, test card 4242…, order confirmations are fake).
 *
 * Identity contract observed live:
 *   - Page title: "Shop · TestverQA"
 *   - Heading:    "Shop"
 *   - 500 products, 12 per page, "Add to cart" (data-testid="add-cart-N"),
 *     filter by name/category/price, sort, paginate.
 */
export class ShopPage extends BasePage {
  readonly page: Page;
  readonly heading: Locator;
  readonly cartLink: Locator;
  readonly cartCount: Locator;
  readonly firstAddToCartButton: Locator;
  readonly searchInput: Locator;
  readonly categorySelect: Locator;
  readonly sortSelect: Locator;
  readonly applyFiltersButton: Locator;

  constructor(page: Page) {
    super(page);
    this.page = page;
    this.heading = page.getByRole('heading', { level: 1 });
    this.cartLink = page.getByTestId('cart-link');
    this.cartCount = page.getByTestId('cart-count');
    this.firstAddToCartButton = page.getByTestId('add-cart-1');
    this.searchInput = page.getByTestId('filter-search');
    // The category/sort selects carry only name= attributes (no test-ids).
    this.categorySelect = page.locator('select[name="category"]');
    this.sortSelect = page.locator('select[name="sort"]');
    this.applyFiltersButton = page.getByTestId('filter-apply');
  }

  async expectLoaded(): Promise<void> {
    await expect(this.heading).toBeVisible();
  }

  async expectTitle(): Promise<void> {
    await expect(this.page).toHaveTitle(SHOP_TITLE);
  }

  async expectHeading(): Promise<void> {
    await expect(this.heading).toHaveText(SHOP_HEADING);
  }

  /** Add the first product on the current page to the cart. */
  async addFirstProductToCart(): Promise<void> {
    await this.firstAddToCartButton.click();
  }

  /** Read the cart badge line-item count as an integer (e.g. "🛒 Cart (3)" → 3). */
  async cartCountValue(): Promise<number> {
    const badge = await this.cartCount.innerText();
    const match = badge.match(/(\d+)/);
    return match ? parseInt(match[1], 10) : 0;
  }

  /** Select the category filter ("Electronics", "Books", …) on the shop sidebar. */
  async selectCategory(category: string): Promise<void> {
    // "Category" dropdown in the shop filter sidebar
    // Alt: [css] [data-testid="filter-category"] (0.99), [xpath] //select[@name='category'] (0.94)
    await this.categorySelect.selectOption(category);
  }

  /** Pick the sort order (e.g. "price-asc" = Price low → high) in the shop sidebar. */
  async selectSort(sort: 'featured' | 'name' | 'price-asc' | 'price-desc' | 'rating'): Promise<void> {
    // "Sort by" dropdown in the shop filter sidebar
    // Alt: [css] [data-testid="filter-sort"] (0.99), [xpath] //select[@name='sort'] (0.94)
    await this.sortSelect.selectOption(sort);
  }

  /** Press the "Apply filters" button of the shop filter sidebar. */
  async applyFilters(): Promise<void> {
    // "Apply filters" button below the shop filter controls
    // Alt: [xpath] //button[normalize-space(text())='Apply filters'] (0.9)
    await this.applyFiltersButton.click();
  }

  /** Add one product to the cart by its numeric product id (e.g. 442). */
  async addToCartById(productId: number | string): Promise<void> {
    // "+ Add" button of the product card with the given product id
    // Alt: [xpath] //button[normalize-space(text())='+ Add'] (0.73)
    const button = this.page.getByTestId(`add-cart-${productId}`);
    await expect(button).toBeVisible({ timeout: 15000 });
    await button.click();
  }

  /**
   * Read the prices of the products currently listed, in display order.
   * Each product card carries its price text (e.g. "$1899.00"); the card is
   * located from its "+ Add" button so the price is scoped to that product.
   */
  async productPrices(): Promise<number[]> {
    const buttons = this.page.locator('[data-testid^="add-cart-"]');
    const count = await buttons.count();
    const prices: number[] = [];

    for (let i = 0; i < count; i++) {
      const card = buttons.nth(i).locator('xpath=ancestor::div[contains(@class,"card")][1]');
      const text = await card.innerText();
      const match = text.match(/\$\s*([\d,]+(?:\.\d{1,2})?)/);
      if (match) {
        prices.push(parseFloat(match[1].replace(/,/g, '')));
      }
    }

    return prices;
  }
}