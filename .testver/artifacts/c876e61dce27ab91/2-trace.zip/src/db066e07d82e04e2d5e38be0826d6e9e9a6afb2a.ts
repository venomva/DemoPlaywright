import { test, expect } from '../fixtures/fixtures';
import type { APIRequestContext } from '@playwright/test';
import { loginAsManager } from '../helpers/auth';
import { loadCustomer } from '../helpers/data';
import { PROFILE_TITLE } from '../pages/ProfilePage';
import { CHECKOUT_TITLE } from '../pages/CheckoutPage';

/**
 * Manager purchase journey — TestverQA shop.
 *
 * browse (Electronics, cheapest first) → add 2 items → cart badge = 2 →
 * SAVE10 coupon (total = subtotal − discount + shipping + tax) → 5-step
 * checkout with the csv customer + Express shipping + test card 4242… →
 * order confirmation → profile shows orders+1 and the new order as newest.
 *
 * Test data: data/customers.csv (first row) supplies the shipping address.
 * Isolation: POST /api/reset {"size":"medium"} — the project's documented
 * reset recipe (see tests/shop/shop.spec.ts).
 */

const RESET_BODY = { size: 'medium' };

/** Reset the practice data through the API before each journey. */
async function resetState(request: APIRequestContext): Promise<void> {
  const res = await request.post('/api/reset', { data: RESET_BODY });
  expect(res.ok(), 'POST /api/reset should succeed').toBeTruthy();
}

test.beforeEach(async ({ page }) => {
  await resetState(page.request);
});

/**
 * The journey PLACES a real order, which bumps the manager account's
 * ORDERS PLACED stat. Reset again afterwards so the shared account keeps its
 * seeded state and the read-only profile suite (which asserts the seeded
 * values) stays green.
 */
test.afterEach(async ({ page }) => {
  await resetState(page.request);
});

test('Manager buys the cheapest electronics with a coupon', async ({
  page,
  loginPage,
  shopPage,
  cartPage,
  checkoutPage,
  profilePage,
}) => {
  const customer = loadCustomer();

  // Log in as the manager (seeded account, no 2FA step).
  await loginAsManager(loginPage);

  // Read the ORDERS PLACED stat as the pre-purchase baseline.
  await profilePage.gotoProfile();
  await expect(page).toHaveTitle(PROFILE_TITLE);
  const ordersBefore = await profilePage.ordersCountValue();

  // Browse the Electronics category, cheapest first.
  await shopPage.goto('/shop');
  await shopPage.selectCategory('Electronics');
  await shopPage.selectSort('price-asc');
  await shopPage.applyFilters();

  // Products must be sorted by price, cheapest first.
  await expect
    .poll(async () => (await shopPage.productPrices()).length, { timeout: 15000 })
    .toBeGreaterThan(1);
  const prices = await shopPage.productPrices();
  expect(prices.length).toBeGreaterThan(1);
  const sorted = [...prices].sort((a, b) => a - b);
  expect(prices).toEqual(sorted);

  // Add the two cheapest products to the cart.
  await shopPage.addToCartById(442);
  await shopPage.addToCartById(331);

  // Cart badge reflects both line items: "🛒 Cart (2)".
  await expect(shopPage.cartCount).toHaveText('2');

  // Open the cart and apply the SAVE10 coupon.
  await shopPage.cartLink.click();
  await expect(cartPage.heading).toBeVisible();
  await cartPage.applyCoupon('SAVE10');
  await expect(cartPage.couponMessage).toBeVisible();

  // Total must equal subtotal − discount + shipping + tax.
  const subtotal = await cartPage.subtotalAmount();
  const discount = await cartPage.summaryAmount('Discount');
  const shipping = await cartPage.shippingAmount();
  const tax = await cartPage.taxAmount();
  const total = await cartPage.totalAmount();
  expect(
    Math.abs(total - (subtotal - discount + shipping + tax)),
    `total ${total} should equal ${subtotal} - ${discount} + ${shipping} + ${tax}`,
  ).toBeLessThan(0.02);

  // Checkout step 1 — shipping address from the csv test data.
  await cartPage.goToCheckout();
  await expect(page).toHaveTitle(CHECKOUT_TITLE);
  await checkoutPage.fillShipping(
    customer.fullName,
    customer.phone,
    customer.address,
    customer.city,
    customer.zip,
  );
  await checkoutPage.goToNextStep();

  // Step 2 — billing (same as shipping is checked by default) → step 3.
  await checkoutPage.goToNextStep();

  // Step 3 — Express shipping (2-3 days, $19.99) → step 4.
  await checkoutPage.selectExpressShipping();
  await checkoutPage.goToNextStep();

  // Step 4 — payment with the sandbox test card → step 5.
  await checkoutPage.fillCardPayment('4242 4242 4242 4242', '12/30', '123');
  await checkoutPage.goToNextStep();

  // Step 5 — accept the terms and place the order.
  await checkoutPage.acceptTerms();
  await checkoutPage.placeOrder();

  // Order confirmation shows the generated order number.
  await expect(page).toHaveURL(/\/shop\/order\/ORD-\d+$/);
  await expect(page.getByTestId('order-number')).toBeVisible();
  const orderNumber = await checkoutPage.orderNumberText();
  expect(orderNumber).toMatch(/^ORD-\d+$/);

  // Profile: orders grew by one and the newest recent order is this order.
  await profilePage.gotoProfile();
  await expect(page).toHaveTitle(PROFILE_TITLE);

  await expect
    .poll(async () => profilePage.ordersCountValue(), { timeout: 15000 })
    .toBe(ordersBefore + 1);

  const recentOrderIds = await profilePage.recentOrderIds();
  expect(recentOrderIds[0]).toBe(orderNumber);
});
